#ifndef REPOSITORIO_H
#define REPOSITORIO_H

#pragma once

#include "classes/Local.h"
#include "classes/Veiculo.h"
#include "classes/Pedido.h"
#include <cstring>
#include <stdexcept>
#include <cstdio>

#define MAX_LOCAIS 100
#define MAX_VEICULOS 100
#define MAX_PEDIDOS 100

class Repositorio {
    Local locais[MAX_LOCAIS];
    Veiculo veiculos[MAX_VEICULOS];
    Pedido pedidos[MAX_PEDIDOS];

    int totalLocais = 0;
    int totalVeiculos = 0;
    int totalPedidos = 0;

    int nextLocalId = 0;
    int nextVeiculoId = 0;
    int nextPedidoId = 0;

public:
    // Locais
    int gerarProximoIdLocal() { return nextLocalId++; }

    int addLocal(Local l) {
        if (totalLocais >= MAX_LOCAIS) throw std::runtime_error("Limite de locais atingido");
        l.setId(gerarProximoIdLocal());
        locais[totalLocais++] = l;
        return l.getId();
    }

    Local* getLocal(int id) {
        for (int i = 0; i < totalLocais; i++) {
            if (locais[i].getId() == id) return &locais[i];
        }
        return nullptr;
    }

    void updateLocal(Local elemento) {
        for (int i = 0; i < totalLocais; i++) {
            if (locais[i].getId() == elemento.getId()) {
                locais[i] = elemento;
                return;
            }
        }
        throw std::runtime_error("Local não encontrado");
    }

    void removeLocal(int id) {
        for (int i = 0; i < totalLocais; i++) {
            if (locais[i].getId() == id) {
                for (int j = i; j < totalLocais - 1; j++)
                    locais[j] = locais[j + 1];
                totalLocais--;
                return;
            }
        }
        throw std::runtime_error("Local não encontrado");
    }

    Local* getAllLocal(int& count) {
        count = totalLocais;
        return locais;
    }

    // Veículos
    int gerarProximoIdVeiculo() { return nextVeiculoId++; }

    int addVeiculo(Veiculo v) {
        if (totalVeiculos >= MAX_VEICULOS) throw std::runtime_error("Limite de veículos atingido");
        v.setId(gerarProximoIdVeiculo());
        veiculos[totalVeiculos++] = v;
        return v.getId();
    }

    Veiculo* getVeiculo(const char* placa) {
        for (int i = 0; i < totalVeiculos; i++) {
            if (strcmp(veiculos[i].getPlaca(), placa) == 0)
                return &veiculos[i];
        }
        return nullptr;
    }

    void updateVeiculo(Veiculo elemento) {
        for (int i = 0; i < totalVeiculos; i++) {
            if (strcmp(veiculos[i].getPlaca(), elemento.getPlaca()) == 0) {
                veiculos[i] = elemento;
                return;
            }
        }
        throw std::runtime_error("Veículo não encontrado");
    }

    void removeVeiculo(const char* placa) {
        for (int i = 0; i < totalVeiculos; i++) {
            if (strcmp(veiculos[i].getPlaca(), placa) == 0) {
                for (int j = i; j < totalVeiculos - 1; j++)
                    veiculos[j] = veiculos[j + 1];
                totalVeiculos--;
                return;
            }
        }
        throw std::runtime_error("Veículo não encontrado");
    }

    Veiculo* getAllVeiculo(int& count) {
        count = totalVeiculos;
        return veiculos;
    }

    // Pedidos
    int gerarProximoIdPedido() { return nextPedidoId++; }

    int addPedido(Pedido p) {
        if (totalPedidos >= MAX_PEDIDOS) throw std::runtime_error("Limite de pedidos atingido");
        p.setId(gerarProximoIdPedido());
        pedidos[totalPedidos++] = p;
        return p.getId();
    }

    Pedido* getPedido(int id) {
        for (int i = 0; i < totalPedidos; i++) {
            if (pedidos[i].getId() == id) return &pedidos[i];
        }
        return nullptr;
    }

    void updatePedido(Pedido elemento) {
        for (int i = 0; i < totalPedidos; i++) {
            if (pedidos[i].getId() == elemento.getId()) {
                pedidos[i] = elemento;
                return;
            }
        }
        throw std::runtime_error("Pedido não encontrado");
    }

    void removePedido(int id) {
        for (int i = 0; i < totalPedidos; i++) {
            if (pedidos[i].getId() == id) {
                for (int j = i; j < totalPedidos - 1; j++)
                    pedidos[j] = pedidos[j + 1];
                totalPedidos--;
                return;
            }
        }
        throw std::runtime_error("Pedido não encontrado");
    }

    Pedido* getAllPedido(int& count) {
        count = totalPedidos;
        return pedidos;
    }

    // Arquivo binário com C-style FILE*
    void salvarBinario(const char* DB_PATH) {
        FILE* file = fopen(DB_PATH, "wb");
        if (!file) throw std::runtime_error("Erro ao abrir arquivo para escrita");

        fwrite(&totalLocais, sizeof(int), 1, file);
        fwrite(locais, sizeof(Local), totalLocais, file);

        fwrite(&totalVeiculos, sizeof(int), 1, file);
        fwrite(veiculos, sizeof(Veiculo), totalVeiculos, file);

        fwrite(&totalPedidos, sizeof(int), 1, file);
        fwrite(pedidos, sizeof(Pedido), totalPedidos, file);

        fclose(file);
    }

    void carregarBinario(const char* DB_PATH) {
        FILE* file = fopen(DB_PATH, "rb");
        if (!file) throw std::runtime_error("Erro ao abrir arquivo para leitura");

        fread(&totalLocais, sizeof(int), 1, file);
        fread(locais, sizeof(Local), totalLocais, file);
        nextLocalId = (totalLocais > 0) ? locais[totalLocais - 1].getId() + 1 : 0;

        fread(&totalVeiculos, sizeof(int), 1, file);
        fread(veiculos, sizeof(Veiculo), totalVeiculos, file);
        nextVeiculoId = (totalVeiculos > 0) ? veiculos[totalVeiculos - 1].getId() + 1 : 0;

        fread(&totalPedidos, sizeof(int), 1, file);
        fread(pedidos, sizeof(Pedido), totalPedidos, file);
        nextPedidoId = (totalPedidos > 0) ? pedidos[totalPedidos - 1].getId() + 1 : 0;

        fclose(file);
    }
};

#endif // REPOSITORIO_H

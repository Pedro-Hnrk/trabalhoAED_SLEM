#ifndef SYSTEMSERVICE_H
#define SYSTEMSERVICE_H

#pragma once
#include "classes/Local.h"
#include "classes/Veiculo.h"
#include "classes/Pedido.h"
#include "database/repositorio.h"
#include "funcs/veiculoService.h"
#include "funcs/pedidoService.h"
#include <limits>
#include <cmath>
#include <iostream>

/**
 * @brief Salva o estado atual do repositório em um arquivo binário.
 */
void salvarDB(Repositorio& repo) {
    repo.salvarBinario("include/database/database.bin");
}

/**
 * @brief Carrega o estado do repositório a partir de um arquivo binário.
 */
void carregarDB(Repositorio& repo) {
    repo.carregarBinario("include/database/database.bin");
}

/**
 * @brief Calcula a distância entre dois locais (usando distância euclidiana).
 */
double calcularDistancia(const Local& l1, const Local& l2) {
    return std::sqrt(std::pow(l2.getCoordenadaX() - l1.getCoordenadaX(), 2) +
                     std::pow(l2.getCoordenadaY() - l1.getCoordenadaY(), 2));
}

/**
 * @brief Seleciona o veículo disponível mais próximo da origem do pedido.
 */
Veiculo* selecionarVeiculo(Repositorio& repo, const Local& origem) {
    VeiculoService veiculoService(&repo);
    int total = 0;
    Veiculo* veiculos = veiculoService.listarVeiculos(total);

    if (!veiculos || total == 0) {
        std::cout << "Nenhum veículo cadastrado." << std::endl;
        return nullptr;
    }

    Veiculo* veiculoSelecionado = nullptr;
    double menorDistancia = std::numeric_limits<double>::max();

    for (int i = 0; i < total; ++i) {
        Veiculo& veiculo = veiculos[i];
        if (veiculo.getStatus()) {
            double distancia = calcularDistancia(origem, veiculo.getLocal());

            if (distancia == 0) {
                veiculoSelecionado = &veiculo;
                break;
            }

            if (distancia < menorDistancia) {
                menorDistancia = distancia;
                veiculoSelecionado = &veiculo;
            }
        }
    }

    if (veiculoSelecionado) {
        veiculoSelecionado->setStatus(false);
        repo.updateVeiculo(*veiculoSelecionado);
    } else {
        std::cout << "Nenhum veículo disponível encontrado." << std::endl;
    }

    return veiculoSelecionado;
}

/**
 * @brief Calcula a distância total da rota de entrega de um pedido.
 */
double calcularRota(const Veiculo& veiculoSelecionado, const Pedido& pedido) {
    double d1 = calcularDistancia(veiculoSelecionado.getLocal(), pedido.getOrigem());
    double d2 = calcularDistancia(pedido.getOrigem(), pedido.getDestino());
    return d1 + d2;
}

/**
 * @brief Finaliza um pedido e atualiza os dados no repositório.
 */
void finalizarPedido(Repositorio& repo, Pedido& pedido, Veiculo& veiculo) {
    PedidoService pedidoService(&repo);

    veiculo.setStatus(true);
    veiculo.setLocal(pedido.getDestino());

    pedido.setStatus(true);
    pedidoService.atualizarPedido(pedido.getId(), pedido.getOrigem(), pedido.getDestino(), pedido.getPeso());
    repo.updateVeiculo(veiculo);
}

/**
 * @brief Realiza o processo completo de entrega de um pedido.
 */
void realizarEntrega(Repositorio& repo, Pedido& pedido) {
    Veiculo* veiculoPtr = selecionarVeiculo(repo, pedido.getOrigem());
    if (!veiculoPtr) {
        std::cerr << "Entrega não pôde ser realizada: nenhum veículo disponível." << std::endl;
        return;
    }

    Veiculo& veiculo = *veiculoPtr;
    double distanciaTotal = calcularRota(veiculo, pedido);

    std::cout << "Veículo selecionado: " << veiculo.getModelo()
              << " (Placa: " << veiculo.getPlaca() << ")" << std::endl;
    std::cout << "ID do pedido: " << pedido.getId() << std::endl;
    std::cout << "Origem: " << pedido.getOrigem().getEndereco().getRua()
              << ", Destino: " << pedido.getDestino().getEndereco().getRua() << std::endl;
    std::cout << "Peso do pedido: " << pedido.getPeso() << " Kg" << std::endl;
    std::cout << "Distância do veículo até a origem: "
              << calcularDistancia(veiculo.getLocal(), pedido.getOrigem()) << " Km" << std::endl;
    std::cout << "Distância da origem até o destino: "
              << calcularDistancia(pedido.getOrigem(), pedido.getDestino()) << " Km" << std::endl;
    std::cout << "Distância total da rota: " << distanciaTotal << " Km" << std::endl;

    std::cout << "Entregando o pedido..." << std::endl;
    finalizarPedido(repo, pedido, veiculo);
    std::cout << "Pedido entregue com sucesso!" << std::endl;
}

#endif // SYSTEMSERVICE_H

#ifndef FUNC_veiculoService_H
#define FUNC_veiculoService_H

#include <iostream>
#include "classes/Endereco.h"
#include "classes/Local.h"
#include "classes/Veiculo.h"
#include "funcs/localService.h"
#include "database/repositorio.h"

class VeiculoService {
private:
    Repositorio* repositorio;
public:
    VeiculoService() = default;
    VeiculoService(Repositorio* repo) : repositorio(repo) {}

    int criarVeiculo(const char* placa, const char* modelo, const Local& local, bool status) {
        Veiculo novo(placa, modelo, local, status);
        if (!novo.setPlaca(placa)) return -1;
        if (!novo.setModelo(modelo)) return -1;
        if (!novo.setLocal(local)) return -1;
        novo.setStatus(true); // Disponível por padrão
        return repositorio->addVeiculo(novo);
    }

    Veiculo* lerVeiculo(const char* placa) {
        return repositorio->getVeiculo(placa);
    }

    bool atualizarVeiculo(const char* placa, const char* modelo, const Local& local, bool status) {
        Veiculo* veiculo = repositorio->getVeiculo(placa);
        if (!veiculo) return false;

        veiculo->setModelo(modelo);
        veiculo->setLocal(local);
        veiculo->setStatus(status);
        repositorio->updateVeiculo(*veiculo);
        return true;
    }

    bool deletarVeiculo(const char* placa) {
        try {
            repositorio->removeVeiculo(placa);
            return true;
        } catch (const std::runtime_error& e) {
            std::cerr << "Erro ao deletar veículo: " << e.what() << std::endl;
            return false;
        }
    }

    Veiculo* listarVeiculos(int& total) {
        return repositorio->getAllVeiculo(total);
    }
};

// ================== Funções auxiliares ==================

void adicionarVeiculo(Repositorio* repo) {
    VeiculoService veiculoService(repo);
    char placa[8], modelo[50];
    Local local;
    bool status = true;

    std::cout << "Digite a placa do veículo (formato AAA0000): ";
    std::cin >> placa;
    std::cin.ignore(); // limpa buffer
    std::cout << "Digite o modelo do veículo: ";
    std::cin.getline(modelo, 50);

    listarLocais(repo);
    std::cout << "Digite o ID do local onde o veículo está estacionado: ";
    int localId;
    std::cin >> localId;

    Local* localPtr = repo->getLocal(localId);
    if (!localPtr) {
        std::cerr << "Local não encontrado." << std::endl;
        return;
    }
    local = *localPtr;

    int id = veiculoService.criarVeiculo(placa, modelo, local, status);
    if (id != -1) {
        std::cout << "Veículo adicionado com sucesso! ID: " << id << std::endl;
    } else {
        std::cerr << "Erro ao adicionar veículo." << std::endl;
    }
}

void listarVeiculos(Repositorio* repo) {
    VeiculoService veiculoService(repo);
    int total = 0;
    Veiculo* veiculos = veiculoService.listarVeiculos(total);

    std::cout << "Lista de veículos:" << std::endl;
    for (int i = 0; i < total; ++i) {
        const Veiculo& veiculo = veiculos[i];
        std::cout << "ID: " << veiculo.getId()
                  << ", Placa: " << veiculo.getPlaca()
                  << ", Modelo: " << veiculo.getModelo()
                  << ", Local: " << veiculo.getLocal().getEndereco().getRua()
                                << ", " << veiculo.getLocal().getEndereco().getCidade()
                                << ", " << veiculo.getLocal().getEndereco().getEstado()
                  << ", Coordenadas: (" << veiculo.getLocal().getCoordenadaX()
                                        << ", " << veiculo.getLocal().getCoordenadaY() << ")"
                  << ", Status: " << (veiculo.getStatus() ? "Disponível" : "Indisponível")
                  << std::endl;
    }
}

void editarVeiculo(Repositorio* repo) {
    VeiculoService veiculoService(repo);
    char placa[8], modelo[50];
    Local local;
    bool status = true;

    std::cout << "Digite a placa do veículo a ser editado: ";
    std::cin >> placa;
    std::cin.ignore();

    Veiculo* veiculo = veiculoService.lerVeiculo(placa);
    if (!veiculo) {
        std::cerr << "Veículo não encontrado." << std::endl;
        return;
    }

    std::cout << "Digite o novo modelo do veículo: ";
    std::cin.getline(modelo, 50);

    listarLocais(repo);
    std::cout << "Digite o ID do novo local onde o veículo está estacionado: ";
    int localId;
    std::cin >> localId;

    Local* localPtr = repo->getLocal(localId);
    if (!localPtr) {
        std::cerr << "Local não encontrado." << std::endl;
        return;
    }
    local = *localPtr;

    if (veiculoService.atualizarVeiculo(placa, modelo, local, status)) {
        std::cout << "Veículo atualizado com sucesso!" << std::endl;
    } else {
        std::cerr << "Erro ao atualizar veículo." << std::endl;
    }
}

void removerVeiculo(Repositorio* repo) {
    VeiculoService veiculoService(repo);
    char placa[8];

    std::cout << "Digite a placa do veículo a ser removido: ";
    std::cin >> placa;

    if (veiculoService.deletarVeiculo(placa)) {
        std::cout << "Veículo removido com sucesso!" << std::endl;
    } else {
        std::cerr << "Erro ao remover veículo." << std::endl;
    }
}

#endif // FUNC_veiculoService_H


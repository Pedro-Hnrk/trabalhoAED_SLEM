#ifndef FUNC_pedidoService_H
#define FUNC_pedidoService_H

#include <iostream>
#include <limits>
#include "classes/Endereco.h"
#include "classes/Local.h"
#include "classes/Veiculo.h"
#include "funcs/localService.h"
#include "database/repositorio.h"

class PedidoService {
private:
    Repositorio* repositorio;
public:
    PedidoService() = default;
    PedidoService(Repositorio* repo) : repositorio(repo) {}

    int criarPedido(const Local& origem, const Local& destino, float peso, bool status) {
        Pedido novo(origem, destino, peso, status);
        if (!novo.setOrigem(origem)) return -1;
        if (!novo.setDestino(destino)) return -1;
        if (!novo.setPeso(peso)) return -1;
        novo.setStatus(false); // por padrão, pendente
        return repositorio->addPedido(novo);
    }

    Pedido* lerPedido(int id) {
        return repositorio->getPedido(id);
    }

    bool atualizarPedido(int id, const Local& origem, const Local& destino, float peso) {
        Pedido* pedido = repositorio->getPedido(id);
        if (!pedido) return false;

        pedido->setOrigem(origem);
        pedido->setDestino(destino);
        pedido->setPeso(peso);
        repositorio->updatePedido(*pedido);
        return true;
    }

    bool deletarPedido(int id) {
        try {
            repositorio->removePedido(id);
            return true;
        } catch (const std::runtime_error& e) {
            std::cerr << "Erro ao deletar pedido: " << e.what() << std::endl;
            return false;
        }
    }

    Pedido* listarPedidos(int& total) {
        return repositorio->getAllPedido(total);
    }
};

// ================== Funções auxiliares ==================

void adicionarPedido(Repositorio* repo) {
    PedidoService pedidoService(repo);
    Local origem, destino;
    float peso;
    bool status = false;

    listarLocais(repo);
    std::cout << "Digite o ID do local de origem: ";
    int origemId;
    std::cin >> origemId;
    std::cin.ignore();

    Local* localOrigem = repo->getLocal(origemId);
    if (!localOrigem) {
        std::cerr << "Local de origem não encontrado." << std::endl;
        return;
    }
    origem = *localOrigem;

    listarLocais(repo);
    std::cout << "Digite o ID do local de destino: ";
    int destinoId;
    std::cin >> destinoId;

    Local* localDestino = repo->getLocal(destinoId);
    if (!localDestino) {
        std::cerr << "Local de destino não encontrado." << std::endl;
        return;
    }
    if (localDestino == localOrigem) {
        std::cerr << "O local de destino não pode ser o mesmo que o de origem." << std::endl;
        return;
    }
    destino = *localDestino;

    std::cout << "Digite o peso do pedido (Kg): ";
    std::cin >> peso;

    int id = pedidoService.criarPedido(origem, destino, peso, status);
    if (id != -1) {
        std::cout << "Pedido adicionado com sucesso! ID: " << id << std::endl;
    } else {
        std::cerr << "Erro ao adicionar pedido." << std::endl;
    }
}

void listarPedidos(Repositorio* repo) {
    PedidoService pedidoService(repo);
    int total = 0;
    Pedido* pedidos = pedidoService.listarPedidos(total);

    std::cout << "Lista de pedidos:" << std::endl;
    for (int i = 0; i < total; ++i) {
        const Pedido& pedido = pedidos[i];
        std::cout << "ID: " << pedido.getId()
                  << ", Origem: " << pedido.getOrigem().getEndereco().getRua()
                  << ", Destino: " << pedido.getDestino().getEndereco().getRua()
                  << ", Peso: " << pedido.getPeso()
                  << " Kg, Status: " << (pedido.getStatus() ? "Entregue" : "Pendente")
                  << std::endl;
    }
}

void listarPedidosPendentes(Repositorio* repo) {
    PedidoService pedidoService(repo);
    int total = 0;
    Pedido* pedidos = pedidoService.listarPedidos(total);

    std::cout << "Lista de pedidos pendentes:" << std::endl;
    for (int i = 0; i < total; ++i) {
        if (!pedidos[i].getStatus()) {
            std::cout << "ID: " << pedidos[i].getId()
                      << ", Origem: " << pedidos[i].getOrigem().getEndereco().getRua()
                      << ", Destino: " << pedidos[i].getDestino().getEndereco().getRua()
                      << ", Peso: " << pedidos[i].getPeso() << " Kg"
                      << std::endl;
        }
    }
}

void listarPedidosEntregues(Repositorio* repo) {
    PedidoService pedidoService(repo);
    int total = 0;
    Pedido* pedidos = pedidoService.listarPedidos(total);

    std::cout << "Lista de pedidos entregues:" << std::endl;
    for (int i = 0; i < total; ++i) {
        if (pedidos[i].getStatus()) {
            std::cout << "ID: " << pedidos[i].getId()
                      << ", Origem: " << pedidos[i].getOrigem().getEndereco().getRua()
                      << ", Destino: " << pedidos[i].getDestino().getEndereco().getRua()
                      << ", Peso: " << pedidos[i].getPeso() << " Kg"
                      << std::endl;
        }
    }
}

void editarPedido(Repositorio* repo) {
    PedidoService pedidoService(repo);
    int id;
    Local origem, destino;
    float peso;

    std::cout << "Digite o ID do pedido a ser editado: ";
    std::cin >> id;

    Pedido* pedido = pedidoService.lerPedido(id);
    if (!pedido) {
        std::cerr << "Pedido não encontrado." << std::endl;
        return;
    }

    listarLocais(repo);
    std::cout << "Digite o ID do novo local de origem: ";
    int origemId;
    std::cin >> origemId;
    Local* localOrigem = repo->getLocal(origemId);
    if (!localOrigem) {
        std::cerr << "Local de origem não encontrado." << std::endl;
        return;
    }
    origem = *localOrigem;

    listarLocais(repo);
    std::cout << "Digite o ID do novo local de destino: ";
    int destinoId;
    std::cin >> destinoId;
    Local* localDestino = repo->getLocal(destinoId);
    if (!localDestino) {
        std::cerr << "Local de destino não encontrado." << std::endl;
        return;
    }
    destino = *localDestino;

    std::cout << "Digite o novo peso do pedido (Kg): ";
    std::cin >> peso;

    if (pedidoService.atualizarPedido(id, origem, destino, peso)) {
        std::cout << "Pedido atualizado com sucesso!" << std::endl;
    } else {
        std::cerr << "Erro ao atualizar pedido." << std::endl;
    }
}

void removerPedido(Repositorio* repo) {
    PedidoService pedidoService(repo);
    int id;

    std::cout << "Digite o ID do pedido a ser removido: ";
    std::cin >> id;

    if (pedidoService.deletarPedido(id)) {
        std::cout << "Pedido removido com sucesso!" << std::endl;
    } else {
        std::cerr << "Erro ao remover pedido." << std::endl;
    }
}

#endif // FUNC_pedidoService_H
